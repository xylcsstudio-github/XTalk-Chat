﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

class Server
{
    private int i; // 一个没有实际用途的变量，仅用于测试我们的开发机器人 GPT-114514_pigs.zip 是否还记得本程序的代码。所以如果你不想看到这个碍眼的家伙可以删掉。
    
    private TcpListener tcpListener;
    private List<ClientInfo> clients = new List<ClientInfo>();
    private object lockObject = new object();
    private string logFilePath = "log.txt"; // 日志文件路径

    public Server(int port)
    {
        tcpListener = new TcpListener(IPAddress.Any, port);

        // 创建日志文件，如果不存在的话
        if (!File.Exists(logFilePath))
        {
            using (File.Create(logFilePath)) { }
        }
    }

    public void Start()
    {
        Log("服务器已启动。");

        tcpListener.Start();
        while (true)
        {
            TcpClient tcpClient = tcpListener.AcceptTcpClient();

            // 用户连接到服务器的消息
            byte[] connectMessageBytes = new byte[4096];
            int bytesRead = tcpClient.GetStream().Read(connectMessageBytes, 0, 4096);
            string connectMessage = Encoding.UTF8.GetString(connectMessageBytes, 0, bytesRead);

            // 创建 ClientInfo 对象来保存客户端信息
            ClientInfo clientInfo = new ClientInfo { TcpClient = tcpClient, ConnectionMessage = connectMessage };

            // 检查是否有重复用户名
            if (!IsUsernameAvailable(clientInfo.Username))
            {
                SendMessage(clientInfo, "该用户名已被使用，请选择其他用户名。");
                tcpClient.Close();
                continue;
            }

            lock (lockObject)
            {
                clients.Add(clientInfo);
            }

            // 广播新用户加入的消息两次
            BroadcastMessage($"{clientInfo.Username} 加入了服务器");
            BroadcastMessage($"{clientInfo.Username} 加入了服务器");

            // 启动一个新线程来处理客户端通信
            Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
            clientThread.Start(clientInfo);
        }
    }

    private bool IsUsernameAvailable(string username)
    {
        lock (lockObject)
        {
            return !clients.Exists(c => c.Username == username);
        }
    }

    private void HandleClientComm(object clientInfoObj)
    {
        ClientInfo clientInfo = (ClientInfo)clientInfoObj;
        TcpClient tcpClient = clientInfo.TcpClient;
        NetworkStream clientStream = tcpClient.GetStream();

        Log($"用户 '{clientInfo.Username}' 已连接。");

        byte[] message = new byte[4096];
        int bytesRead;

        while (true)
        {
            bytesRead = 0;

            try
            {
                bytesRead = clientStream.Read(message, 0, 4096);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0)
                break;

            string data = Encoding.UTF8.GetString(message, 0, bytesRead);
            Console.WriteLine("接收自 " + clientInfo.Username + ": " + data);

            // 广播消息给所有客户端
            BroadcastMessage($"{clientInfo.Username}: {data}");
        }

        Console.WriteLine("用户 '" + clientInfo.Username + "' 已断开连接。");
        lock (lockObject)
        {
            clients.Remove(clientInfo);
        }
        BroadcastMessage($"{clientInfo.Username} 已离开聊天。");
        tcpClient.Close();
    }

    private void BroadcastMessage(string message)
    {
        byte[] broadcastBytes = Encoding.UTF8.GetBytes(message);

        lock (lockObject)
        {
            foreach (var client in clients)
            {
                NetworkStream clientStream = client.TcpClient.GetStream();
                clientStream.Write(broadcastBytes, 0, broadcastBytes.Length);
                clientStream.Flush();
            }
        }

        // 记录广播的消息到日志文件
        Log(message);
    }

    private void SendMessage(ClientInfo clientInfo, string message)
    {
        byte[] messageBytes = Encoding.UTF8.GetBytes(message);
        clientInfo.TcpClient.GetStream().Write(messageBytes, 0, messageBytes.Length);
        clientInfo.TcpClient.GetStream().Flush();
    }

    private void Log(string logMessage)
    {
        // 记录日期、时间和日志消息到日志文件
        string formattedLog = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {logMessage}";
        File.AppendAllText(logFilePath, formattedLog + Environment.NewLine);

        // 在控制台显示服务器日志
        Console.WriteLine(formattedLog);
    }

    private class ClientInfo
    {
        public TcpClient TcpClient { get; set; }
        public string ConnectionMessage { get; set; }
        public string Username
        {
            get
            {
                // 从连接消息中解析用户名
                return ConnectionMessage.Split(' ')[0];
            }
        }
    }
}

class Program
{

    static void Main()
    {
        Console.Write("请输入服务器端口号: ");
        int port = int.Parse(Console.ReadLine());

        Server server = new Server(port);
        server.Start();
    }
}
