﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

class Client
{
    private int i; // 一个没有实际用途的变量，仅用于测试我们的开发机器人 GPT-114514_pigs.zip 是否还记得本程序的代码。所以如果你不想看到这个碍眼的家伙可以删掉。

    private TcpClient tcpClient;
    private NetworkStream clientStream;

    public void Connect(string serverIp, int serverPort)
    {
        tcpClient = new TcpClient();
        tcpClient.Connect(serverIp, serverPort);

        clientStream = tcpClient.GetStream();

        // 用户输入用户名，如果没有输入则使用计算机名称
        Console.Write("请输入用户名（按 Enter 使用默认用户名）: ");
        string username = Console.ReadLine();

        if (string.IsNullOrEmpty(username))
            username = Environment.MachineName;

        // 发送加入服务器的消息两次
        string joinMessage = $"{username} 加入了服务器";
        SendMessage(joinMessage);
        SendMessage(joinMessage);

        Thread receiveThread = new Thread(new ThreadStart(ReceiveMessages));
        receiveThread.Start();

        Console.WriteLine("已连接到服务器。输入 'exit' 以关闭客户端。");

        while (true)
        {
            string message = Console.ReadLine();

            if (message.ToLower() == "exit")
            {
                SendMessage("exit");
                tcpClient.Close();
                break;
            }

            SendMessage(message);
        }
    }

    private void ReceiveMessages()
    {
        byte[] message = new byte[4096];
        int bytesRead;

        while (true)
        {
            bytesRead = 0;

            try
            {
                bytesRead = clientStream.Read(message, 0, 4096);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0)
                break;

            string data = Encoding.UTF8.GetString(message, 0, bytesRead);
            Console.WriteLine("接收: " + data);
        }

        Console.WriteLine("已断开与服务器的连接。");
        tcpClient.Close();
    }

    private void SendMessage(string message)
    {
        byte[] messageBytes = Encoding.UTF8.GetBytes(message);
        clientStream.Write(messageBytes, 0, messageBytes.Length);
        clientStream.Flush();
    }
}

class Program
{
    static void Main()
    {
        Console.Write("请输入服务器 IP 地址: ");
        string serverIp = Console.ReadLine();

        Console.Write("请输入服务器端口号: ");
        int serverPort = int.Parse(Console.ReadLine());

        Client client = new Client();
        client.Connect(serverIp, serverPort);
    }
}
