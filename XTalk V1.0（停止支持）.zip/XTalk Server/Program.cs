﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

class Server
{
    private TcpListener tcpListener;
    private List<TcpClient> clients = new List<TcpClient>();

    public Server(int port)
    {
        tcpListener = new TcpListener(IPAddress.Any, port);
    }

    public void Start()
    {
        tcpListener.Start();
        Console.WriteLine("服务器已启动。");

        while (true)
        {
            TcpClient client = tcpListener.AcceptTcpClient();
            clients.Add(client);

            Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
            clientThread.Start(client);
        }
    }

    private void HandleClientComm(object clientObj)
    {
        TcpClient tcpClient = (TcpClient)clientObj;
        NetworkStream clientStream = tcpClient.GetStream();

        byte[] message = new byte[4096];
        int bytesRead;

        try
        {
            bytesRead = clientStream.Read(message, 0, 4096);
        }
        catch
        {
            return;
        }

        if (bytesRead == 0)
            return;

        string data = Encoding.UTF8.GetString(message, 0, bytesRead);
        string username = string.IsNullOrEmpty(data) ? Environment.MachineName : data;

        Console.WriteLine("用户 '" + username + "' 已连接。");

        // 广播消息给所有客户端
        BroadcastMessage(username + " 已加入聊天。");

        while (true)
        {
            bytesRead = 0;

            try
            {
                bytesRead = clientStream.Read(message, 0, 4096);
            }
            catch
            {
                break;
            }

            if (bytesRead == 0)
                break;

            data = Encoding.UTF8.GetString(message, 0, bytesRead);
            Console.WriteLine("接收自 " + username + ": " + data);

            // 广播消息给所有客户端
            BroadcastMessage(username + ": " + data);
        }

        Console.WriteLine("用户 '" + username + "' 已断开连接。");
        clients.Remove(tcpClient);
        tcpClient.Close();
    }

    private void BroadcastMessage(string message)
    {
        byte[] broadcastBytes = Encoding.UTF8.GetBytes(message);

        foreach (var client in clients)
        {
            NetworkStream clientStream = client.GetStream();
            clientStream.Write(broadcastBytes, 0, broadcastBytes.Length);
            clientStream.Flush();
        }
    }
}

class Program
{
    static void Main()
    {
        Console.Write("请输入服务器端口号: ");
        int port = int.Parse(Console.ReadLine());

        Server server = new Server(port);
        server.Start();
    }
}
